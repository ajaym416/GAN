# Maluuba NewsQA
Maluuba's news questions and answer data.

You can find more information about the dataset at: https://datasets.maluuba.com/NewsQA

Information on how to use the dataset can be found at: https://github.com/Maluuba/newsqa

## Legal

Notice:  CNN articles are used here by permission from The Cable News Network (CNN).  CNN does not waive any rights of ownership in its articles and materials.  CNN is not a partner of, nor does it endorse, Maluuba or its activities.

Terms: See LICENSE.pdf
